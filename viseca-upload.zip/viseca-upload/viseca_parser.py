"""Viseca/Raiffeisen Kreditkartenabrechnung (PDF) -> CSV im Format der Firefly-Pipeline."""
import csv, hashlib, io, re
from decimal import Decimal as D
import pdfplumber

CC = {"CH": "CHE", "IE": "IRL", "SE": "SWE", "NL": "NLD", "DE": "DEU", "FR": "FRA",
      "IT": "ITA", "AT": "AUT", "GB": "GBR", "US": "USA", "LU": "LUX", "ES": "ESP"}
MN = {"APPLE.COM/BILL": "Apple", "WAL*FC STALLEN EVENT": "FC St.Gallen Event",
      "Nestle Nespresso S.A.": "Nespresso", "Migros MR Neumarkt": "Migros Restaurant"}
HDR = ["TransactionId", "CardId", "Date", "ValutaDate", "Amount", "Currency", "OriginalAmount",
       "OriginalCurrency", "MerchantName", "MerchantPlace", "MerchantCountry", "StateType",
       "Details", "Type", "Exchange Rate"]

LINE = re.compile(r"^(\d{2}\.\d{2}\.\d{2}) (\d{2}\.\d{2}\.\d{2}) (.+?) ([\d']+\.\d{2}) ?(-)?$")
CARD = re.compile(r"^\d{4} \d{2}XX XXXX (\d{4}) ")
TOTAL = re.compile(r"^Total Karte .* ([\d']+\.\d{2})$")
ABRECHNUNG = re.compile(r"^Abrechnung vom (\d{2}\.\d{2}\.\d{4})")


def _d(s):  # 26.09.26 -> 2026-09-26
    d, m, y = s.split(".")
    return f"20{y}-{m}-{d}"


def _amt(s):
    return D(s.replace("'", ""))


def parse_pdf(fileobj):
    """Gibt dict zurück: last4, abrechnung, rows[], payment, total (laut PDF)."""
    text = []
    with pdfplumber.open(fileobj) as pdf:
        for page in pdf.pages:
            text += (page.extract_text() or "").splitlines()
    res = {"last4": None, "abrechnung": None, "rows": [], "payment": None, "total": None}
    for raw in text:
        line = " ".join(raw.split())
        if m := ABRECHNUNG.match(line):
            res["abrechnung"] = m.group(1)
        elif m := CARD.match(line):
            res["last4"] = m.group(1)
        elif m := TOTAL.match(line):
            res["total"] = _amt(m.group(1))
        elif m := LINE.match(line):
            d, v, desc, amt, neg = m.groups()
            if desc.startswith("Ihre Zahlung"):
                res["payment"] = (_d(d), _d(v), _amt(amt))
                continue
            head, _, tail = desc.rpartition(", ")
            place, _, cc = tail.rpartition(" ")
            if not head or len(cc) != 2:   # Fallback ohne Ort
                head, place, cc = desc, "", "CH"
            res["rows"].append((_d(d), _d(v), head, place, cc, _amt(amt)))
    s = sum(r[5] for r in res["rows"])
    if res["total"] is not None and s != res["total"]:
        raise ValueError(f"Summe {s} != PDF-Total {res['total']} (Karte …{res['last4']})")
    if not res["last4"] or not res["rows"]:
        raise ValueError("Keine Karte/Buchungen im PDF gefunden")
    return res


def load_cardids(path):
    with open(path, newline="", encoding="utf-8") as f:
        return [r["CardId"].strip() for r in csv.DictReader(f)]


def build_csv(parsed, cardids):
    """parsed: Liste von parse_pdf-Ergebnissen. Gibt (csv_text, info) zurück."""
    out = io.StringIO()
    w = csv.writer(out, lineterminator="\r\n")
    w.writerow(HDR)
    info = []
    for p in parsed:
        match = [c for c in cardids if c.endswith(p["last4"])]
        if len(match) != 1:
            raise ValueError(f"CardId für Karte …{p['last4']} nicht eindeutig in konten_visa.csv: {match}")
        card = match[0]
        rows = [(*r, card) for r in p["rows"]]
        if p["payment"]:
            d, v, a = p["payment"]
            rows.append((d, v, "Ihre Zahlung - Danke", "", "", -a, ""))
        rows.sort(key=lambda r: (r[0], r[1]), reverse=True)   # Zahlung zuletzt -> carry-forward in visa_split
        for i, (d, v, name, place, cc, amt, cid) in enumerate(rows):
            pay = name.startswith("Ihre Zahlung")
            merchant = "" if pay else ("Spotify" if name.startswith("Spotify") else MN.get(name, name))
            tid = "TRX" + v.replace("-", "") + f"{int(hashlib.sha1(f'{card}|{d}|{v}|{name}|{amt}|{i}'.encode()).hexdigest(), 16) % 10**11:011d}"
            a = f"{amt:.3f}"
            w.writerow([tid, cid, f"{d} 00:00:00", f"{v} 00:00:00", a, "CHF", a, "CHF", merchant,
                        place, CC.get(cc, cc) if cc else "", "BOOKED", name, "merchant", "1.000000"])
        info.append({"card": card, "n": len(p["rows"]), "sum": p["total"] or sum(r[5] for r in p["rows"]),
                     "payment": p["payment"][2] if p["payment"] else None})
    return out.getvalue(), info
