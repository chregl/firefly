#!/bin/bash
# Einmalig auf srv01 ausführen:  sudo ./install-host.sh
set -e
[ "$EUID" -eq 0 ] || { echo "Bitte mit sudo ausführen"; exit 1; }
cd "$(dirname "$0")"
install -d -o chegl -g chegl -m 755 /home/chegl/control/trigger
install -m 755 firefly-backup-web.sh /usr/local/bin/firefly-backup-web.sh
install -m 644 firefly-backup-web.service firefly-backup-web.path /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now firefly-backup-web.path
systemctl status firefly-backup-web.path --no-pager
echo
echo "Fertig. Test:  touch /home/chegl/control/trigger/backup.now && journalctl -u firefly-backup-web -f"
