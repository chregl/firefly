#!/bin/bash
# Läuft als root (systemd), gestartet über die Trigger-Datei aus viseca-upload.
# Installiert nach /usr/local/bin/firefly-backup-web.sh
set -u
D=/home/chegl/control/trigger          # = /control/trigger im Container
OWNER=chegl:chegl                      # = uid 1000 des Containers
LOG=/var/log/firefly-backup-web.log
BACKUP=$(command -v firefly_backup.sh || echo /home/chegl/firefly_backup.sh)

# Datei atomar ins Trigger-Verzeichnis schreiben (Inhalt von stdin)
publish() {
  local tmp
  tmp=$(mktemp "$D/.tmp.XXXXXX") || return 1
  cat > "$tmp"
  chown "$OWNER" "$tmp"; chmod 644 "$tmp"
  mv -f -T "$tmp" "$D/$1"
}

rm -f "$D/backup.now"                  # Trigger sofort verbrauchen
START=$(date +%s)
printf '{"state":"running","started":%s}\n' "$START" | publish status.json
: | publish backup.log

# Log-Ausschnitt alle 3 s für die Weboberfläche bereitstellen
( while sleep 3; do tail -n 60 "$LOG" 2>/dev/null | publish backup.log; done ) &
TAILPID=$!

"$BACKUP" backup > "$LOG" 2>&1
RC=$?

kill "$TAILPID" 2>/dev/null; wait "$TAILPID" 2>/dev/null
tail -n 60 "$LOG" | publish backup.log

if [ "$RC" -eq 0 ]; then S=ok; else S=error; fi
printf '{"state":"%s","started":%s,"finished":%s,"rc":%s}\n' "$S" "$START" "$(date +%s)" "$RC" | publish status.json
exit "$RC"
