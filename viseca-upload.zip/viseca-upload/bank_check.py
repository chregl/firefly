"""Raiffeisen Kontoauszug (CSV, ';'-getrennt, alle Konten in einer Datei) prüfen und zusammenfassen.

Format: IBAN;Booked At;Text;Credit/Debit Amount;Balance;Valuta Date
"""
import csv, io
from datetime import datetime
from decimal import Decimal as D, InvalidOperation

REQUIRED = ["IBAN", "Booked At", "Text", "Credit/Debit Amount", "Balance", "Valuta Date"]


def norm_iban(s):
    return "".join(s.split()).upper()


def decode(raw: bytes) -> str:
    for enc in ("utf-8-sig", "cp1252"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            pass
    return raw.decode("latin-1")


def load_konten(path):
    """konten.csv (IBAN,Account,Name) -> {iban: {account, name}} in Dateireihenfolge."""
    out = {}
    with open(path, newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            out[norm_iban(r["IBAN"])] = {"account": r["Account"].strip(), "name": r["Name"].strip()}
    return out


def _amount(s, line, col):
    try:
        return D((s or "").strip().replace("'", ""))
    except InvalidOperation:
        raise ValueError(f"Zeile {line}: ungültiger Wert in «{col}»: {s!r}")


def _date(s, line, col):
    try:
        return datetime.strptime((s or "").strip()[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
    except ValueError:
        raise ValueError(f"Zeile {line}: ungültiges Datum in «{col}»: {s!r}")


def _chain(rows):
    """Saldo-Kette je Konto prüfen. -> (Reihenfolge 'asc'|'desc'|None, erste Lücke als Zeilennummer)."""
    gap = next((i for i in range(1, len(rows))
                if rows[i]["bal"] != rows[i - 1]["bal"] + rows[i]["amt"]), None)
    if gap is None:
        return "asc", None
    if next((i for i in range(1, len(rows))
             if rows[i - 1]["bal"] != rows[i]["bal"] + rows[i - 1]["amt"]), None) is None:
        return "desc", None
    return None, rows[gap]["line"]


def analyse(text, konten):
    """Gibt dict zurück: text (normalisiert), start, end, rows, accounts[], unknown{}, missing[]."""
    text = text.replace("\r\n", "\n").replace("\r", "\n").strip("\n")
    if not text.strip():
        raise ValueError("Leere Datei")
    rd = csv.DictReader(io.StringIO(text), delimiter=";")
    missing_cols = [c for c in REQUIRED if c not in (rd.fieldnames or [])]
    if missing_cols:
        raise ValueError(f"Spalten fehlen: {', '.join(missing_cols)} (erwartet: {';'.join(REQUIRED)})")

    per, dates, total = {}, [], 0
    for line, row in enumerate(rd, start=2):
        if not any((v or "").strip() for v in row.values() if not isinstance(v, list)):
            continue
        iban = norm_iban(row["IBAN"] or "")
        if not iban:
            raise ValueError(f"Zeile {line}: IBAN fehlt")
        booked = _date(row["Booked At"], line, "Booked At")
        valuta = _date(row["Valuta Date"], line, "Valuta Date")
        per.setdefault(iban, []).append({
            "line": line, "booked": booked, "valuta": valuta,
            "amt": _amount(row["Credit/Debit Amount"], line, "Credit/Debit Amount"),
            "bal": _amount(row["Balance"], line, "Balance"),
        })
        dates += [booked, valuta]
        total += 1
    if not total:
        raise ValueError("Keine Buchungen in der Datei")

    accounts = []
    for iban, k in konten.items():          # Reihenfolge wie in konten.csv
        rows = per.get(iban)
        if not rows:
            continue
        order, gap_line = _chain(rows)
        accounts.append({
            "iban": iban, **k, "n": len(rows), "sum": sum(r["amt"] for r in rows),
            "first": min(r["booked"] for r in rows), "last": max(r["booked"] for r in rows),
            "chain": order, "gap_line": gap_line,
            "balance": rows[0]["bal"] if order == "desc" else rows[-1]["bal"],
        })
    return {
        "text": text + "\n", "rows": total, "start": min(dates), "end": max(dates),
        "accounts": accounts,
        "unknown": {i: len(r) for i, r in per.items() if i not in konten},
        "missing": [k["name"] for i, k in konten.items() if i not in per],
    }
