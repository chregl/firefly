import csv, html, json, os, re, secrets, subprocess, threading
from datetime import datetime
from decimal import Decimal as D
from io import BytesIO
from pathlib import Path
from flask import Flask, request, abort, redirect, jsonify
import viseca_parser as vp
import bank_check

CONTROL = Path(os.environ.get("CONTROL_DIR", "/control"))
KONTEN_BANK = CONTROL / "konten.csv"
KONTEN_VISA = CONTROL / "konten_visa.csv"
FIREFLY_URL = os.environ.get("FIREFLY_URL", "").rstrip("/")   # z.B. http://192.168.0.7:8080
LOCK = threading.Lock()
TOKEN_RE = re.compile(r"[0-9a-f]{16}")
DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024

PAGE = """<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>Firefly-Abgleich</title><style>
body{font:16px system-ui;max-width:1000px;margin:2rem auto;padding:0 1rem}
pre{background:#111;color:#ddd;padding:1rem;overflow:auto;font-size:13px;max-height:50vh;margin:.3rem 0}
button,input,textarea{font:inherit;padding:.4rem .7rem;margin:.2rem 0}textarea{width:100%;font:13px monospace}
table{border-collapse:collapse;width:100%}td,th{padding:.4rem .5rem;border-bottom:1px solid #ddd;text-align:left;vertical-align:top}
td.r,th.r{text-align:right}small{color:#666}.ok{color:#080}.err{color:#b00}.warn{color:#a60}
.res td{border-bottom:2px solid #bbb}.box{background:#f6f6f6;padding:.6rem 1rem;border-radius:6px;margin:1rem 0}
@media(prefers-color-scheme:dark){body{background:#1b1b1b;color:#ddd}.box{background:#262626}small{color:#999}td,th{border-color:#444}a{color:#6af}}
</style><h1><a href=/ style="color:inherit;text-decoration:none">Firefly-Abgleich</a></h1>{{BODY}}"""


def page(body, status=200):
    return PAGE.replace("{{BODY}}", body), status


def run(cmd):
    head = f">>> {' '.join(cmd)}\n"
    try:
        r = subprocess.run(cmd, cwd=CONTROL, capture_output=True, text=True, timeout=900)
    except (OSError, subprocess.TimeoutExpired) as e:
        return False, f"{head}[Fehler: {e}]"
    ok = r.returncode == 0
    return ok, f"{head}{r.stdout}{r.stderr}" + ("" if ok else f"\n[Exit {r.returncode}]")


def iso(ddmmyyyy):
    return datetime.strptime(ddmmyyyy, "%d.%m.%Y").strftime("%Y-%m-%d")


def firefly_link(account):
    base = FIREFLY_URL or f"{request.scheme}://{request.host.split(':')[0]}:8080"
    return f"{base}/accounts/show/{account}"


# ---------------------------------------------------------------- Batch-Speicher
def bdir(token):
    return CONTROL / "upload" / token


def load(token):
    if not TOKEN_RE.fullmatch(token) or not (bdir(token) / "batch.json").exists():
        abort(404)
    return json.loads((bdir(token) / "batch.json").read_text(encoding="utf-8"))


def save(token, batch):
    (bdir(token) / "batch.json").write_text(json.dumps(batch, ensure_ascii=False, indent=1), encoding="utf-8")


def merge_csv(texts):
    lines = []
    for n, t in enumerate(texts):
        part = t.replace("\r\n", "\n").replace("\r", "\n").strip("\n").split("\n")
        lines += part if n == 0 else part[1:]
    return "\n".join(lines) + "\n"


def statement_for(rel_dir, iban):
    d = CONTROL / rel_dir
    if (d / f"{iban}.csv").exists():
        return f"{rel_dir}/{iban}.csv"
    c = [p for p in d.glob("*.csv") if bank_check.norm_iban(p.stem) == iban]
    return f"{rel_dir}/{c[0].name}" if len(c) == 1 else None


# ---------------------------------------------------------------- Startseite + Upload
@app.get("/")
def index():
    recent = ""
    up = CONTROL / "upload"
    if up.exists():
        dirs = sorted((p for p in up.iterdir() if p.is_dir() and TOKEN_RE.fullmatch(p.name)
                       and (p / "batch.json").exists()), key=lambda p: p.stat().st_mtime, reverse=True)[:5]
        if dirs:
            items = "".join(
                f"<li><a href=/b/{p.name}>{datetime.fromtimestamp(p.stat().st_mtime):%d.%m.%Y %H:%M}</a></li>"
                for p in dirs)
            recent = f"<h3>Letzte Uploads</h3><ul>{items}</ul>"
    return page("""<form method=post action=/upload enctype=multipart/form-data>
<p>Dateien hochladen: Viseca-PDFs und/oder Bank-CSV (mehrere gleichzeitig möglich):<br>
<input type=file name=files accept=".pdf,.csv,.txt" multiple></p>
<details><summary>oder Bank-CSV einfügen</summary>
<textarea name=paste rows=8 placeholder="IBAN;Booked At;Text;Credit/Debit Amount;Balance;Valuta Date"></textarea></details>
<p>Start (leer = automatisch): <input name=start placeholder=YYYY-MM-DD size=12>
Ende (leer = automatisch): <input name=end placeholder=YYYY-MM-DD size=12></p>
<button>Hochladen und Konten anzeigen</button></form>""" + recent)


@app.post("/upload")
def upload():
    try:
        start_o, end_o = request.form.get("start", "").strip(), request.form.get("end", "").strip()
        for v in (start_o, end_o):
            if v and not DATE_RE.fullmatch(v):
                raise ValueError(f"Ungültiges Datum «{v}» (erwartet YYYY-MM-DD)")
        pdfs, csvs = [], []
        for f in request.files.getlist("files"):
            if not f.filename:
                continue
            raw = f.read()
            if raw[:5] == b"%PDF-":
                pdfs.append((f.filename, raw))
            elif f.filename.lower().endswith((".csv", ".txt")):
                csvs.append((f.filename, bank_check.decode(raw)))
            else:
                raise ValueError(f"{f.filename}: nur PDF (Viseca) oder CSV (Bank) erlaubt")
        if request.form.get("paste", "").strip():
            csvs.append(("eingefügter Text", request.form["paste"]))
        if not pdfs and not csvs:
            raise ValueError("Keine Datei hochgeladen")

        accounts, warnings = [], []
        bank_text = visa_text = None

        if csvs:
            konten = bank_check.load_konten(KONTEN_BANK)
            for name, text in csvs:
                try:
                    bank_check.analyse(text, konten)
                except ValueError as e:
                    raise ValueError(f"{name}: {e}")
            bank_text = merge_csv([t for _, t in csvs])
            res = bank_check.analyse(bank_text, konten)
            b_start, b_end = start_o or res["start"], end_o or res["end"]
            for k in res["accounts"]:
                ok = bool(k["chain"])
                accounts.append({
                    "kind": "bank", "name": k["name"], "account": k["account"], "key": k["iban"],
                    "label": "IBAN …" + k["iban"][-4:], "n": k["n"], "first": k["first"], "last": k["last"],
                    "sum": str(k["sum"]), "start": b_start, "end": b_end, "ok": ok,
                    "check": (f"Endsaldo {k['balance']}, Saldo-Kette lückenlos ✓" if ok else
                              f"⚠️ Saldo-Lücke bei Zeile {k['gap_line']} (fehlen Buchungen im Export?)"),
                })
            for iban, n in res["unknown"].items():
                warnings.append(f"IBAN {iban} ({n} Buchungen) steht nicht in konten.csv und wird nicht abgeglichen.")

        if pdfs:
            parsed = []
            for name, raw in pdfs:
                try:
                    parsed.append(vp.parse_pdf(BytesIO(raw)))
                except Exception as e:
                    raise ValueError(f"{name}: {e}")
            visa_text, vinfo = vp.build_csv(parsed, vp.load_cardids(KONTEN_VISA))
            v_start = start_o or min([p["payment"][0] for p in parsed if p["payment"]]
                                     + [min(r[0] for r in p["rows"]) for p in parsed])
            ends = [iso(p["abrechnung"]) for p in parsed if p["abrechnung"]] \
                or [max(r[0] for p in parsed for r in p["rows"])]
            v_end = end_o or max(ends)
            with KONTEN_VISA.open(newline="", encoding="utf-8-sig") as f:
                vkonten = {r["CardId"].strip(): r for r in csv.DictReader(f)}
            cards = {}
            for p, i in zip(parsed, vinfo):
                c = cards.setdefault(i["card"], {"n": 0, "sum": D(0), "dates": [], "total": True, "pay": []})
                c["n"] += i["n"]
                c["sum"] += D(i["sum"])
                c["dates"] += [r[0] for r in p["rows"]]
                c["total"] = c["total"] and p["total"] is not None
                if i["payment"]:
                    c["pay"].append(str(i["payment"]))
            for card, c in cards.items():
                row = vkonten[card]
                chk = "Summe stimmt mit PDF-Total ✓" if c["total"] else "kein Total im PDF zum Prüfen"
                if c["pay"]:
                    chk += ", Zahlung " + " + ".join(c["pay"])
                accounts.append({
                    "kind": "visa", "name": (row.get("Name") or "").strip() or f"Visa …{card[-4:]}",
                    "account": row["Account"].strip(), "key": "".join(card.split()).upper(),
                    "label": "Karte …" + card[-4:], "n": c["n"], "first": min(c["dates"]), "last": max(c["dates"]),
                    "sum": str(c["sum"]), "start": v_start, "end": v_end, "ok": c["total"], "check": chk,
                })
    except Exception as e:
        return page(f"<p class=err>❌ {html.escape(str(e))}</p><a href=/>zurück</a>", 400)

    token = secrets.token_hex(8)
    d = bdir(token)
    for sub in ("bank", "visa"):
        (d / sub).mkdir(parents=True)
    rel = f"upload/{token}"
    with LOCK:
        if bank_text is not None:
            (d / "bank_alle.csv").write_text(bank_text, encoding="utf-8")
            ok, log = run(["./iban_split.py", "--in", f"{rel}/bank_alle.csv", "--outdir", f"{rel}/bank"])
            if not ok:
                warnings.append("Aufteilen der Bank-CSV fehlgeschlagen:\n" + log)
        if visa_text is not None:
            (d / "visa_alle.csv").write_text(visa_text, encoding="utf-8-sig")
            ok, log = run(["./visa_split.py", "--in", f"{rel}/visa_alle.csv", "--outdir", f"{rel}/visa"])
            if not ok:
                warnings.append("Aufteilen der Visa-CSV fehlgeschlagen:\n" + log)
    for a in accounts:
        if a["kind"] == "bank":
            a["statement"] = statement_for(f"{rel}/bank", a["key"])
        else:
            st = f"{rel}/visa/{a['key']}.csv"
            a["statement"] = st if (CONTROL / st).exists() else None
        a["status"], a["log"] = "new", ""
        if not a["statement"]:
            warnings.append(f"{a['name']}: nach dem Aufteilen kein Auszug gefunden, Abgleich nicht möglich.")
    save(token, {"token": token, "created": datetime.now().isoformat(timespec="seconds"),
                 "accounts": accounts, "warnings": warnings})
    return redirect(f"/b/{token}", 303)


# ---------------------------------------------------------------- Kontenliste
JS = """
const TOKEN="__TOKEN__", bk=document.getElementById('backup');
function sync(){document.querySelectorAll('button.run').forEach(b=>{b.disabled=!bk.checked||b.dataset.done==='1'||b.dataset.nost==='1'});}
bk.addEventListener('change',sync); sync();
function showLink(box,link){const c=box.querySelector('.link');c.textContent='';
  if(!link)return;const a=document.createElement('a');a.href=link;a.target='_blank';a.rel='noopener';
  a.textContent='➜ Konto in Firefly öffnen';c.append('✅ Abgeglichen. ',a);}
async function act(i,a){
  const btns=document.querySelectorAll('#row'+i+' button'),box=document.getElementById('res'+i),pre=box.querySelector('pre');
  btns.forEach(b=>b.disabled=true);box.hidden=false;pre.textContent='läuft …';
  try{
    const r=await fetch('/b/'+TOKEN+'/'+i+'/'+a,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'backup='+(bk.checked?1:0)});
    const j=await r.json();pre.textContent=j.log||j.error||'';
    if(j.done){document.querySelector('#row'+i+' button.run').dataset.done='1';showLink(box,j.link);}
  }catch(e){pre.textContent='Fehler: '+e;}
  document.querySelectorAll('#row'+i+' button.dry').forEach(b=>b.disabled=false);sync();
}
"""


def render_batch(token, b):
    def section(kind, title):
        rows = [(i, a) for i, a in enumerate(b["accounts"]) if a["kind"] == kind]
        if not rows:
            return ""
        a0 = rows[0][1]
        out = [f"<h2>{title}</h2><p><small>Zeitraum für den Abgleich: {a0['start']} bis {a0['end']}</small></p>",
               "<table><tr><th>Konto<th class=r>Buchungen<th>Buchungsdaten<th>Prüfung<th></tr>"]
        for i, a in rows:
            done = a["status"] == "done"
            nost = "" if a["statement"] else " data-nost=1"
            link = f"✅ Abgeglichen. <a href=\"{html.escape(firefly_link(a['account']))}\" target=_blank rel=noopener>➜ Konto in Firefly öffnen</a>" if done else ""
            cls = "ok" if a["ok"] else "warn"
            out.append(
                f"<tr id=row{i}><td>{html.escape(a['name'])}<br><small>Firefly-Konto {html.escape(a['account'])}, "
                f"{html.escape(a['label'])}</small><td class=r>{a['n']}<td>{a['first']}<br>bis {a['last']}"
                f"<td class={cls}>{html.escape(a['check'])}"
                f"<td><button class=dry onclick=\"act({i},'dry')\"{'' if a['statement'] else ' disabled'}>Vorschau</button> "
                f"<button class=run onclick=\"act({i},'run')\" data-done={'1' if done else '0'}{nost} disabled>Abgleichen</button></tr>"
                f"<tr id=res{i} class=res{'' if (a['log'] or done) else ' hidden'}><td colspan=5>"
                f"<pre>{html.escape(a['log'])}</pre><div class=link>{link}</div></tr>")
        return "".join(out) + "</table>"

    warn = "".join(f"<p class=warn>⚠️ {html.escape(w)}</p>" for w in b["warnings"])
    return (f"<p><a href=/>← neuer Upload</a></p>{warn}"
            "<div class=box><label><input type=checkbox id=backup> Backup erstellt "
            "(<code>sudo firefly_backup.sh backup</code>), erst dann sind die Buttons «Abgleichen» aktiv</label></div>"
            + section("bank", "Bankkonten") + section("visa", "Kreditkarten (Visa)")
            + f"<script>{JS.replace('__TOKEN__', token)}</script>")


@app.get("/b/<token>")
def batch_page(token):
    return page(render_batch(token, load(token)))


@app.post("/b/<token>/<int:i>/<action>")
def account_action(token, i, action):
    b = load(token)
    if action not in ("dry", "run") or not 0 <= i < len(b["accounts"]):
        abort(404)
    if action == "run" and request.form.get("backup") != "1":
        return jsonify(error="Bitte zuerst das Backup bestätigen"), 400
    with LOCK:
        b = load(token)                      # Stand innerhalb des Locks neu lesen
        a = b["accounts"][i]
        if not a["statement"]:
            return jsonify(error="Kein Auszug für dieses Konto vorhanden"), 400
        if action == "run" and a["status"] == "done":
            return jsonify(error="Bereits abgeglichen (für einen neuen Lauf neu hochladen)", done=True,
                           link=firefly_link(a["account"])), 409
        cmd = ["./firefly_reconcile_pdf.py", "--account", a["account"], "--start", a["start"],
               "--end", a["end"], "--statement", a["statement"]]
        if action == "dry":
            cmd.append("--dry-run")
        ok, log = run(cmd)
        a["log"] = log[-20000:]
        if action == "run":
            a["status"] = "done" if ok else "error"
        save(token, b)
    done = a["status"] == "done"
    return jsonify(ok=ok, log=a["log"], done=done, link=firefly_link(a["account"]) if done else None)
